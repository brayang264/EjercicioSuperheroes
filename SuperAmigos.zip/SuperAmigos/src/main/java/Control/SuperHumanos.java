/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Model.Person;

/**
 *
 * @author JhomarArrieta
 * 
 * nos llega una invasion de alphasentauro y la unica oportunidad
 * de salvar la humanidad es convocar a los suoerhumanos, haga una app para 
 * registar superhumanos 
 * 
 * minimo tiene un superpoder
 * 
 * 
 */
public class SuperHumanos{

        public boolean validarFuerza(int force){
            return force>=500;
        }
        public boolean validarVision(int vision){
            return vision>100;
        }
        public void ValidarHeroe(Person persona){
            
        }

    
}
